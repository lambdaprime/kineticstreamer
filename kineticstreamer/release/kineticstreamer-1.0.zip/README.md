kineticstreamer - Java module to do serialization of Java objects to stream of bytes and back.

lambdaprime <id.blackmesa@gmail.com>

# Requirements

Java 11

# Arrays

**kineticstreamer** does not support serialization of arrays of primitive types. If you still
need to use primitive type arrays please use their wrapped version (Integer[], Long[], etc).