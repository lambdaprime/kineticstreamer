kineticstreamer - Java module to do (de)serialization of Java objects into streams. By default it supports object conversion to stream of bytes and back. But it is extendible to any other format as well.

lambdaprime <id.blackmesa@gmail.com>

# Requirements

Java 11

