kineticstreamer - Java module to do serialization of Java objects to stream of bytes and back.

lambdaprime <id.blackmesa@gmail.com>

# Requirements

Java 11
