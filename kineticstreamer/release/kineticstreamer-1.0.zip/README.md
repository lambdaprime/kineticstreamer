kineticstreamer - Java module to do (de)serialization of Java objects. By default it supports object convertion to stream of bytes and back. But it is extendable to any other format as well.

lambdaprime <id.blackmesa@gmail.com>

# Requirements

Java 11
